import led from 'sense-hat-led'
import nodeimu from 'nodeimu'

const imu = new nodeimu.IMU()

function displayResult(err, data) {
    if (err) {
        console.error(err)
        return
    }
    console.log('---')
    console.log('Time: ' + data.timestamp.toISOString())
    console.log('Temperature: ' + data.temperature.toFixed(2) + ' °C')
    console.log('Pressure: ' + data.pressure.toFixed(2) + ' mbar')
    console.log('Humidity: ' + data.humidity.toFixed(2) + '%')

    display(data);
}

function beginMeasurement() {
    imu.getValue(displayResult)
}

// Once a second
setInterval(beginMeasurement, 1000)


function display(data) {
    // if humidity is highier than 40, show hot and temperature
    let humidity = data.humidity.toFixed(2)
    if(humidity > 20){
        //say("WET!");
    }
    led.sync.setPixels(createGraph(humidity))
    led.sync.sleep(1)
}


function say(message) {
    for (const letter of message) {
        led.sync.showLetter(letter)
        led.sync.sleep(0.45)
        led.sync.clear()
        led.sync.sleep(0.05)
    }
}

function createGraph(proportion) {
    let green = [0, 255, 0]
    let red = [255, 0, 0]
    let blue =[0,0,255]
    let colour = green
    if(proportion > 40){
        colour = red    
    }
    if(proportion<30){
        colour = blue
    }
    
    const image = Array(8 * 8)
    for (let i = 0; i < image.length; i++) {
        if (i <= proportion * image.length) {
            image[i] = colour
        } else {
            image[i] = [0, 0, 64]
        }
    }
    return image
}
